package ${package};

import org.junit.Test;

public class MySinkTaskTest {
  @Test
  public void test() {
    // Congrats on a passing test!
  }
}
