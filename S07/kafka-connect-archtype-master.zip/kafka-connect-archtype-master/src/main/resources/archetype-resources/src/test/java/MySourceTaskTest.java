package ${package};

import org.junit.Test;

public class MySourceTaskTest {
  @Test
  public void test() {
    // Congrats on a passing test!
  }
}