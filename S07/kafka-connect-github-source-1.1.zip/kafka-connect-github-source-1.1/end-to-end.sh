#!/usr/bin/env bash
./build.sh
./run.sh